Program ini digunakan untuk menentukan jadwal pelajaran yang dapat diambil tiap semesternya bekerja dengan menggunakan algoritma Decrease and Conquer
Dimana program akan menyelesaikan permasalahan dengan membagi persoalan menjadi n-1 atau sejenisnya. Program ini akan membaca file dan mengubah isi file tersebut ke dalam bentuk Directed Acyclic Graph. Setelah itu dilakukan selection sort terhadap graph berdasarkan banyaknya edges yang dimiliki oleh graph, kemudian dilakukan pengambilan mata kuliah satu persatu sesuai dengan syarat yang telah ditetapkan pada file. Setelah itu program akan menelusuri node satu persatu berdasarkan mata kuliah yang sudah diambil, jika prasyarat terpenuhi, program akan menambahkan mata kuliah tersebut kedalam daftar mata kuliah yang sudah diambil, begitu seterusnya hingga semua mata kuliah berhasil diambil.

Program akan meminta user untuk memasukkan input berupa nama dari file yang terdapat pada folder test.

Author : Ariya Adinatha / 13519048 / K1
Umur : 20 tahun
Status : Positif depresi
